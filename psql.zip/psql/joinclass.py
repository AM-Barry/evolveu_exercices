class Client:
    
    def __init__(self, name, credit, date):
        self.name = name
        self.credit = credit
        self.date = date
        
    
    